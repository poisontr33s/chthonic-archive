# HF Model Ranking Snapshot

- Captured: 2026-02-27T18:25:14.839Z
- Snapshot ID: 2026-02-27T18-25-14-839Z
- Candidates: 563
- Sources: 8
- Target VRAM (GB): 24
- Benchmark Source: C:\Users\erdno\chthonic-archive\claude-codex-gemini\session_resumption_pickup\LOCAL_UNCENSORED_BENCHMARK_20260219_231719.json
- Benchmark Entries: 4
- DB: codex\mailbox\cache\hf-model-rankings.db

## Top Models

| Rank | Model | Score | Trend | DL | Likes | Fit | BenchQ | EstVRAM | Created |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|
| 1 | Qwen/Qwen3.5-35B-A3B | 0.6409 | 627 | 258764 | 627 | 0.22 | 1.00 | 61.25 | 2026-02-24T09:39:25.000Z |
| 2 | Qwen/Qwen3-0.6B | 0.5959 | 21 | 10568748 | 1112 | 1.00 | 1.00 | 1.05 | 2025-04-27T03:40:08.000Z |
| 3 | TeichAI/Qwen3-14B-Claude-4.5-Opus-High-Reasoning-Distill-GGUF | 0.5865 | 201 | 60686 | 230 | 0.97 | 1.00 | 24.5 | 2025-12-10T09:46:30.000Z |
| 4 | Qwen/Qwen2.5-7B-Instruct | 0.5801 | 22 | 18024732 | 1101 | 1.00 | 1.00 | 12.25 | 2024-09-16T11:55:40.000Z |
| 5 | Qwen/Qwen3.5-27B | 0.5770 | 402 | 107964 | 402 | 0.34 | 1.00 | 47.25 | 2026-02-24T09:41:56.000Z |
| 6 | Qwen/Qwen3-ASR-1.7B | 0.5766 | 28 | 668444 | 540 | 1.00 | 1.00 | 2.97 | 2026-01-28T03:22:40.000Z |
| 7 | Qwen/Qwen3-8B | 0.5746 | 16 | 5344422 | 961 | 1.00 | 1.00 | 14 | 2025-04-27T03:42:21.000Z |
| 8 | Qwen/Qwen3-VL-8B-Instruct | 0.5692 | 20 | 7628167 | 780 | 1.00 | 1.00 | 14 | 2025-10-11T07:23:39.000Z |
| 9 | Qwen/Qwen3-4B-Instruct-2507 | 0.5686 | 18 | 3619470 | 753 | 1.00 | 1.00 | 7 | 2025-08-05T10:58:03.000Z |
| 10 | Qwen/Qwen3-VL-2B-Instruct | 0.5606 | 10 | 13085190 | 337 | 1.00 | 1.00 | 3.5 | 2025-10-19T13:13:24.000Z |
| 11 | Nanbeige/Nanbeige4.1-3B | 0.5594 | 210 | 283033 | 825 | 1.00 | 0.00 | 5.25 | 2026-02-10T03:45:56.000Z |
| 12 | Qwen/Qwen3-Embedding-0.6B | 0.5571 | 8 | 4098244 | 888 | 1.00 | 1.00 | 1.05 | 2025-06-03T14:25:32.000Z |
| 13 | Qwen/Qwen3-Embedding-8B | 0.5444 | 7 | 1846737 | 593 | 1.00 | 1.00 | 14 | 2025-06-03T14:39:10.000Z |
| 14 | Qwen/Qwen3.5-397B-A17B | 0.5425 | 353 | 725954 | 1111 | 0.00 | 1.00 | 694.75 | 2026-02-16T04:55:12.000Z |
| 15 | Qwen/Qwen3-4B | 0.5394 | 0 | 5173769 | 559 | 1.00 | 1.00 | 7 | 2025-04-27T03:41:29.000Z |
| 16 | Qwen/Qwen3-VL-4B-Instruct | 0.5382 | 7 | 1244706 | 340 | 1.00 | 1.00 | 7 | 2025-10-11T07:23:22.000Z |
| 17 | Qwen/Qwen3-1.7B | 0.5365 | 0 | 5495060 | 424 | 1.00 | 1.00 | 2.97 | 2025-04-27T03:41:05.000Z |
| 18 | Qwen/Qwen3-Coder-Next | 0.5331 | 92 | 685871 | 1016 | 0.45 | 1.00 | n/a | 2026-01-30T15:08:18.000Z |
| 19 | unsloth/Qwen3.5-35B-A3B-GGUF | 0.5297 | 288 | 264531 | 288 | 0.22 | 1.00 | 61.25 | 2026-02-24T14:48:31.000Z |
| 20 | Qwen/Qwen2.5-1.5B-Instruct | 0.5224 | 0 | 6858830 | 623 | 1.00 | 1.00 | 2.62 | 2024-09-17T14:10:29.000Z |
| 21 | Qwen/Qwen3-4B-Thinking-2507 | 0.5217 | 8 | 578362 | 559 | 1.00 | 1.00 | 7 | 2025-08-05T11:02:27.000Z |
| 22 | Qwen/Qwen3-TTS-12Hz-1.7B-CustomVoice | 0.5192 | 104 | 1071196 | 1206 | 1.00 | 0.00 | 2.97 | 2026-01-21T08:56:49.000Z |
| 23 | Qwen/Qwen2.5-0.5B-Instruct | 0.5189 | 0 | 6902085 | 466 | 1.00 | 1.00 | 0.88 | 2024-09-16T11:52:46.000Z |
| 24 | Qwen/Qwen3-14B | 0.5170 | 0 | 1322031 | 374 | 0.97 | 1.00 | 24.5 | 2025-04-27T03:42:45.000Z |
| 25 | Qwen/Qwen2.5-3B-Instruct | 0.5165 | 0 | 6400031 | 407 | 1.00 | 1.00 | 5.25 | 2024-09-17T14:08:52.000Z |
| 26 | Qwen/Qwen2.5-VL-3B-Instruct | 0.5150 | 8 | 2370816 | 620 | 1.00 | 1.00 | 5.25 | 2025-01-26T09:25:35.000Z |
| 27 | zai-org/GLM-5 | 0.5129 | 262 | 189082 | 1631 | 0.45 | 0.00 | n/a | 2026-02-11T04:55:46.000Z |
| 28 | unsloth/Qwen3-Coder-Next-GGUF | 0.5120 | 64 | 563997 | 427 | 0.45 | 1.00 | n/a | 2026-02-03T13:10:01.000Z |
| 29 | Qwen/Qwen2.5-Coder-7B-Instruct | 0.5083 | 0 | 1371664 | 655 | 1.00 | 1.00 | 12.25 | 2024-09-17T13:38:49.000Z |
| 30 | Qwen/Qwen3.5-122B-A10B | 0.5058 | 327 | 107821 | 327 | 0.03 | 1.00 | 213.5 | 2026-02-24T09:43:37.000Z |
| 31 | meta-llama/Llama-3.1-8B-Instruct | 0.5053 | 23 | 6505143 | 5498 | 1.00 | 0.00 | 14 | 2024-07-18T08:56:00.000Z |
| 32 | Qwen/Qwen2.5-0.5B | 0.5003 | 0 | 1228541 | 377 | 1.00 | 1.00 | 0.88 | 2024-09-15T12:15:39.000Z |
| 33 | Qwen/Qwen2.5-7B | 0.5002 | 0 | 1935625 | 266 | 1.00 | 1.00 | 12.25 | 2024-09-15T12:17:40.000Z |
| 34 | Qwen/Qwen3-0.6B-FP8 | 0.4998 | 0 | 1540097 | 57 | 1.00 | 1.00 | 1.05 | 2025-04-28T12:26:36.000Z |
| 35 | Qwen/Qwen2-1.5B-Instruct | 0.4991 | 0 | 3435665 | 160 | 1.00 | 1.00 | 2.62 | 2024-06-03T09:08:12.000Z |
| 36 | unsloth/DeepSeek-R1-0528-Qwen3-8B-GGUF | 0.4988 | 4 | 91554 | 384 | 1.00 | 1.00 | 14 | 2025-05-29T14:17:25.000Z |
| 37 | Qwen/Qwen2.5-14B-Instruct | 0.4952 | 0 | 1501076 | 318 | 0.97 | 1.00 | 24.5 | 2024-09-16T11:56:10.000Z |
| 38 | meta-llama/Meta-Llama-3-8B | 0.4908 | 13 | 2102140 | 6470 | 1.00 | 0.00 | 14 | 2024-04-17T09:35:16.000Z |
| 39 | LocoreMind/LocoOperator-4B | 0.4882 | 209 | 1295 | 209 | 1.00 | 0.00 | 7 | 2026-02-23T00:59:09.000Z |
| 40 | Qwen/Qwen2.5-Coder-1.5B-Instruct | 0.4873 | 0 | 1662230 | 106 | 1.00 | 1.00 | 2.62 | 2024-09-18T09:41:47.000Z |

## Inputs

- trending_text_generation: https://huggingface.co/api/models?filter=text-generation&sort=trendingScore&direction=-1&limit=80
- downloads_text_generation: https://huggingface.co/api/models?filter=text-generation&sort=downloads&direction=-1&limit=80
- likes_text_generation: https://huggingface.co/api/models?filter=text-generation&sort=likes&direction=-1&limit=80
- search_hermes: https://huggingface.co/api/models?search=hermes&sort=trendingScore&direction=-1&limit=80
- search_gemma_3_uncensored: https://huggingface.co/api/models?search=gemma%203%20uncensored&sort=trendingScore&direction=-1&limit=80
- search_qwen: https://huggingface.co/api/models?search=qwen&sort=trendingScore&direction=-1&limit=80
- search_deepseek: https://huggingface.co/api/models?search=deepseek&sort=trendingScore&direction=-1&limit=80
- search_mistral: https://huggingface.co/api/models?search=mistral&sort=trendingScore&direction=-1&limit=80
