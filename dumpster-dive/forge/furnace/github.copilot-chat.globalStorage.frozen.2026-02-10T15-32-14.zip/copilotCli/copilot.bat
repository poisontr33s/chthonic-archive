@echo off
powershell -ExecutionPolicy Bypass -File "c:\Users\erdno\AppData\Roaming\Code - Insiders\User\globalStorage\github.copilot-chat\copilotCli\copilot.ps1" %*
